<?php

//基础配置

$config = [
    'mch_id'    =>  '100001',
    'mch_key'    =>  '772ae1d32322f49508307b2f31a0107f',
    'notify_url'    =>  'http://'.$_SERVER['HTTP_HOST'].'/notify.php',
    'return_url'    =>  'http://'.$_SERVER['HTTP_HOST'].'/return.php'
];
